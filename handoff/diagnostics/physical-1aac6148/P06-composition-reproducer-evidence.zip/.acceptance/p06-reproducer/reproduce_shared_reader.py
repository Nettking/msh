"""Bounded exact-source shared-consumer composition diagnostic; no live runtime."""
from __future__ import annotations

import asyncio
import json
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from catalog.ai.relay_remote import RelayRemoteAIEndpoint
from catalog.capabilities.relay_lifecycle import RelayLifecycleEndpoint
from catalog.federation.commit_tracking import DurableAcknowledgementStore
from catalog.federation.phase_d_client import PhaseDLogicalStorageClient
from catalog.federation.phase_d_control import PhaseDControlPlane
from catalog.federation.relay_storage import RelayStorageEndpoint
from catalog.flask_app.services.federation_storage_authority_install import (
    FederationStorageAuthorityMonitor,
)
from catalog.flask_app.services import trusted_storage_authority_runtime as runtime
from catalog.flask_app.tests.test_storage_authority_local_provider_runtime import (
    _LoopbackRelayClient,
    _register_primary,
    _settings,
)


async def scenario(directory: Path, *, retained_upstream: bool) -> dict:
    directory.mkdir(parents=True, exist_ok=False)
    settings = _settings(directory)
    client = _LoopbackRelayClient("node-creator")
    now = datetime.now(timezone.utc)
    control = PhaseDControlPlane(settings.storage_control_database)
    provider_id = runtime._builtin_local_provider_id(client.node_id)
    _register_primary(control, session_id=settings.session_id,
                      provider_id=provider_id, node_id=client.node_id, now=now)
    ai = RelayRemoteAIEndpoint(client)
    await ai.start()
    endpoint = RelayStorageEndpoint(client, message_source=ai)
    service = runtime._ensure_builtin_local_storage_service(
        endpoint=endpoint, control=control, client=client, settings=settings)
    assert service is not None
    await endpoint.start()
    await asyncio.sleep(0)
    channel = runtime.SharedRecorderAwareStorageControlRelayChannel(client, endpoint)
    await channel.start()
    bridge = SimpleNamespace(_endpoint=ai, _endpoint_lock=threading.RLock())
    shared = SimpleNamespace(bridge=bridge, message_source=ai)
    if retained_upstream:
        # Analysis was composed while bridge still exposed the original stage.
        lifecycle = RelayLifecycleEndpoint(client, message_source=bridge._endpoint)
        await lifecycle.start()
        await asyncio.sleep(0)
    view = FederationStorageAuthorityMonitor._install_storage_view(shared, channel)
    assert view is not None
    if not retained_upstream:
        lifecycle = RelayLifecycleEndpoint(client, message_source=bridge._endpoint)
        await lifecycle.start()
    logical = PhaseDLogicalStorageClient(
        session_id=settings.session_id, actor_node_id=client.node_id,
        control_plane=control, transport=endpoint,
        acknowledgements=DurableAcknowledgementStore(Path(settings.acknowledgements_database)))
    content = {"schema": "test.batch.v1", "value": 42}
    started = asyncio.get_running_loop().time()
    committed = False
    error = None
    diverted = None
    try:
        try:
            result = await logical.ingest_batch(
                group_id="fcp-local-storage", dataset_id="test-dataset",
                batch_id="batch-1", idempotency_key="test-dataset:batch-1",
                content=content, created_at=now)
            committed = result.committed
        except TimeoutError:
            error = "TimeoutError"
        if retained_upstream:
            message = await lifecycle.receive_other(timeout=1)
            diverted = {
                "kind": message.payload.get("kind"),
                "message": message.payload.get("message"),
                "frame_ok": json.loads(message.payload["frame"]).get("ok"),
            }
        local_content = service.provider.read(
            session_id=settings.session_id, group_id="fcp-local-storage", batch_id="batch-1")
        return {
            "composition": "analysis-retained-original-upstream" if retained_upstream else "analysis-behind-storage-view",
            "timeout_seconds": endpoint.request_timeout,
            "elapsed_seconds": round(asyncio.get_running_loop().time() - started, 3),
            "coordinator_committed": committed,
            "exception": error,
            "provider_content_present_and_equal": local_content == content,
            "authenticated_storage_reply_diverted_to_lifecycle_other": diverted,
            "analysis_still_reads_original_ai_endpoint": lifecycle.message_source is ai,
        }
    finally:
        await lifecycle.close()
        await channel.close()
        await endpoint.close()
        await ai.close()


async def main() -> None:
    base = Path(__file__).resolve().parent / "run-1"
    base.mkdir(exist_ok=False)
    red = await scenario(base / "retained-upstream", retained_upstream=True)
    green = await scenario(base / "ordered-composition", retained_upstream=False)
    result = {
        "candidate": "1aac6148759d7b2fd488ec26b97e1a786bdafa80",
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "scope": "isolated exact-source queue composition with checked-in loopback transport fixture and real local provider/control/acknowledgements",
        "red": red, "green_control": green,
        "product_patched": False, "live_runtime_accessed": False,
        "protected_data_accessed": False, "physical_pass": False,
    }
    assert red["exception"] == "TimeoutError"
    assert red["provider_content_present_and_equal"]
    assert red["authenticated_storage_reply_diverted_to_lifecycle_other"] == {
        "kind": "fcp-storage-v1", "message": "response", "frame_ok": True}
    assert green["coordinator_committed"] and green["exception"] is None
    (base / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
